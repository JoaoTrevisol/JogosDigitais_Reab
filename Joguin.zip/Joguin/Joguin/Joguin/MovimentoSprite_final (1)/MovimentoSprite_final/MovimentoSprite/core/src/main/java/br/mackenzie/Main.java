package br.mackenzie;

import com.badlogic.gdx.ApplicationListener;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.utils.Array;
import com.badlogic.gdx.utils.ScreenUtils;
import com.badlogic.gdx.utils.viewport.FitViewport;

public class Main implements ApplicationListener {
    SpriteBatch spriteBatch;
    FitViewport viewport;

    Fundo fundo;
    Personagem personagem;

    Array<Fantasma> fantasmas;
    float tempoGerarFantasma = 0f;
    float intervaloGeracao = 3f;
    float velocidadeFantasma = 2.5f;

    boolean personagemAtivo = true;

    @Override
    public void create() {
        spriteBatch = new SpriteBatch();
        viewport = new FitViewport(8, 5);

        fundo = new Fundo();
        personagem = new Personagem();
        personagem.centralizar(viewport);

        fantasmas = new Array<>();
    }

    @Override
    public void render() {
        float delta = Gdx.graphics.getDeltaTime();

        if (personagemAtivo) {
            input(delta);
            personagem.update(delta, viewport);
        }

        fundo.atualizar(delta);

        // Aumenta velocidade conforme fundo
        switch (fundo.getIndiceAtual()) {
            case 0: velocidadeFantasma = 2.5f; break;
            case 1: velocidadeFantasma = 3.5f; break;
            case 2: velocidadeFantasma = 5f; break;
        }

        // Geração de fantasmas
        tempoGerarFantasma += delta;
        if (tempoGerarFantasma >= intervaloGeracao) {
            tempoGerarFantasma = 0f;
            float alturaChao = 0f;
            fantasmas.add(new Fantasma(viewport, alturaChao, velocidadeFantasma));
        }

        // Atualiza fantasmas e verifica colisões
        for (int i = fantasmas.size - 1; i >= 0; i--) {
            Fantasma f = fantasmas.get(i);
            f.update(delta);

            // Verifica colisão
            if (personagemAtivo && f.getHitbox().overlaps(personagem.getHitbox())) {
                personagemAtivo = false; // personagem desaparece
            }

            if (f.saiuDaTela()) {
                f.dispose();
                fantasmas.removeIndex(i);
            }
        }

        // Renderização
        ScreenUtils.clear(Color.WHITE);
        viewport.apply();
        spriteBatch.setProjectionMatrix(viewport.getCamera().combined);

        spriteBatch.begin();
        fundo.render(spriteBatch, viewport);
        if (personagemAtivo) personagem.render(spriteBatch);
        for (Fantasma f : fantasmas) f.render(spriteBatch);
        spriteBatch.end();
    }

    private void input(float delta) {
        float velocidade = 1f;

        if (Gdx.input.isKeyPressed(Input.Keys.RIGHT)) {
            personagem.moverDireita(delta, velocidade);
            fundo.moverDireita(delta, velocidade);
        } else {
            personagem.idle();
        }

        if (Gdx.input.isKeyJustPressed(Input.Keys.SPACE)) {
            personagem.pular();
        }
    }

    @Override
    public void resize(int width, int height) {
        viewport.update(width, height, true);
    }

    @Override public void pause() {}
    @Override public void resume() {}

    @Override
    public void dispose() {
        spriteBatch.dispose();
        fundo.dispose();
        personagem.dispose();
        for (Fantasma f : fantasmas) f.dispose();
    }
}