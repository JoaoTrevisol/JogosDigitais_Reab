package br.mackenzie;

import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Animation;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
//import com.badlogic.gdx.math.MathUtils;
import com.badlogic.gdx.math.Rectangle;
import com.badlogic.gdx.utils.viewport.FitViewport;

public class Personagem {
    private Animation<TextureRegion> animacaoCorrida;
    private Animation<TextureRegion> animacaoPulo;
    private float stateTimeCorrida;
    private float stateTimePulo;
    private TextureRegion frameAtual;

    private Rectangle hitbox;
    private float posX, posY;
    private boolean olhandoDireita = true;

    private boolean noChao = true;
    private float velY = 0f;
    private final float gravidade = -15f;
    private final float forcaPulo = 7f;

    private final float largura = 1f;
    private final float altura = 1f;

    public Personagem() {
        TextureRegion[] framesCorrida = new TextureRegion[8];
        for (int i = 0; i < 8; i++) {
            Texture t = new Texture("Run" + (i + 1) + ".png");
            framesCorrida[i] = new TextureRegion(t);
        }
        animacaoCorrida = new Animation<>(0.1f, framesCorrida);

        TextureRegion[] framesPulo = new TextureRegion[6];
        for (int i = 0; i < 6; i++) {
            Texture t = new Texture("Jump" + (i + 1) + ".png");
            framesPulo[i] = new TextureRegion(t);
        }
        animacaoPulo = new Animation<>(0.1f, framesPulo);

        frameAtual = framesCorrida[0];
        hitbox = new Rectangle(posX, posY, largura, altura);
    }

    public void centralizar(FitViewport viewport) {
        posX = (viewport.getWorldWidth() - largura) / 2f;
        posY = 0;
        hitbox.set(posX, posY, largura, altura);
    }

    public void update(float delta, FitViewport viewport) {
        if (!noChao) {
            velY += gravidade * delta;
            posY += velY * delta;

            stateTimePulo += delta;
            frameAtual = animacaoPulo.getKeyFrame(stateTimePulo, false);

            if (posY <= 0) {
                posY = 0;
                velY = 0;
                noChao = true;
            }
        }

        hitbox.set(posX, posY, largura, altura);
    }

    public void moverDireita(float delta, float velocidade) {
        olhandoDireita = true;
        if (noChao) {
            stateTimeCorrida += delta;
            frameAtual = animacaoCorrida.getKeyFrame(stateTimeCorrida, true);
        }
    }

    public void moverEsquerda(float delta, float velocidade) {
        olhandoDireita = false;
        if (noChao) {
            stateTimeCorrida += delta;
            frameAtual = animacaoCorrida.getKeyFrame(stateTimeCorrida, true);
        }
    }

    public void idle() {
        if (noChao) {
            frameAtual = animacaoCorrida.getKeyFrames()[0];
        }
    }

    public void pular() {
        if (noChao) {
            velY = forcaPulo;
            noChao = false;
            stateTimePulo = 0f;
        }
    }

    public void render(SpriteBatch batch) {
        if (olhandoDireita) {
            batch.draw(frameAtual, posX, posY, largura, altura);
        } else {
            batch.draw(frameAtual, posX + largura, posY, -largura, altura);
        }
    }

    public Rectangle getHitbox() {
        return hitbox;
    }

    public void dispose() {
        for (TextureRegion t : animacaoCorrida.getKeyFrames()) t.getTexture().dispose();
        for (TextureRegion t : animacaoPulo.getKeyFrames()) t.getTexture().dispose();
    }
}