package br.mackenzie;

import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.utils.viewport.FitViewport;
import com.badlogic.gdx.math.Rectangle;

public class Fantasma {
    private Texture textura;
    private float x, y;
    private float largura = 0.8f;
    private float altura = 0.8f;
    private float velocidade;
    private Rectangle hitbox;

    public Fantasma(FitViewport viewport, float y, float velocidade) {
        textura = new Texture("fantasma.png");
        this.x = viewport.getWorldWidth() + largura;
        this.y = y;
        this.velocidade = velocidade;
        this.hitbox = new Rectangle(x, y, largura, altura);
    }

    public void update(float delta) {
        x -= velocidade * delta;
        hitbox.setPosition(x, y);
    }

    public void render(SpriteBatch batch) {
        batch.draw(textura, x, y, largura, altura);
    }

    public boolean saiuDaTela() {
        return x + largura < 0;
    }
    public Rectangle getHitbox() {
        return hitbox;
    }

    public void dispose() {
        textura.dispose();
    }

}